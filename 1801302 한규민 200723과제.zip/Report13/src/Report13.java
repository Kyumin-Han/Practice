
public class Report13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int cal = 0;
		
		for(int i = 1; i <= 10; i++)
		{
			for(int j = 1; j <= 10; j++)
			{
				cal = i * j;
				System.out.print(cal + " ");
			}
			System.out.print("\n");
		}
	}

}
