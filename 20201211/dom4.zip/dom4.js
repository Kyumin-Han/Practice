// function displayImage() {
//     const images = document.querySelector('img');

//     images.setAttribute("src" ,"beach3.jpg");
//     images.setAttribute("width", "50%");
// }

// window.onload = function () {
//     const btn = document.querySelector(".btn");

//     btn.onclick = function () {
//         const images = document.querySelector('img');
//         images.setAttribute("src", "beach3.jpg");
//         images.setAttribute("width", "50%");
//     }
// }

// window.addEventListener('load', displayOn);

// function displayOn() {
//     const btn = document.querySelector(".btn");

//     btn.addEventListener('click', function () {
//         const images = document.querySelector('img');

//         images.setAttribute("src", "beach3.jpg");

//         images.setAttribute("width", "50%");
//     });
// }